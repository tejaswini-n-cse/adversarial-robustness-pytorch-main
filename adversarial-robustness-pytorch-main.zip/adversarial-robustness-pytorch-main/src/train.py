"""
Training loop for the base (non-robust) CNN on clean MNIST.
Saves the trained model to models/base_cnn.pt for use in later phases.
"""

import os
import torch
import torch.nn as nn
import torch.optim as optim
from model import get_dataloaders, SimpleCNN, device

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "..", "models", "base_cnn.pt")


def train(num_epochs=5, lr=0.001, model_path=MODEL_PATH):
    train_loader, test_loader = get_dataloaders()
    model = SimpleCNN().to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0

        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)

            optimizer.zero_grad()          # clear gradients from previous step
            outputs = model(images)        # forward pass
            loss = criterion(outputs, labels)
            loss.backward()                # backward pass: compute dLoss/dWeights
            optimizer.step()                # update weights

            running_loss += loss.item()

        avg_loss = running_loss / len(train_loader)
        print(f"Epoch [{epoch+1}/{num_epochs}] - Avg Loss: {avg_loss:.4f}")

    # Evaluate on clean test set
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = 100 * correct / total
    print(f"Test Accuracy (clean): {accuracy:.2f}%")

    torch.save(model.state_dict(), model_path)
    print(f"Model saved to {model_path}")


if __name__ == "__main__":
    train()