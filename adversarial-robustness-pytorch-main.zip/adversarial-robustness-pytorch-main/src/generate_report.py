"""
Regenerates the epsilon-sweep comparison as a plot and markdown table,
saved into reports/. Reuses evaluate_under_attack() from fgsm_attack.py
so the report always reflects the actual saved model weights.
"""

import os
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from model import get_dataloaders, SimpleCNN, device
from fgsm_attack import evaluate_under_attack

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_MODEL_PATH = os.path.join(BASE_DIR, "..", "models", "base_cnn.pt")
ROBUST_MODEL_PATH = os.path.join(BASE_DIR, "..", "models", "robust_cnn.pt")
REPORTS_DIR = os.path.join(BASE_DIR, "..", "reports")


def load_model(path):
    model = SimpleCNN().to(device)
    model.load_state_dict(torch.load(path, map_location=device))
    model.eval()
    return model


def main():
    os.makedirs(REPORTS_DIR, exist_ok=True)

    _, test_loader = get_dataloaders()
    criterion = nn.CrossEntropyLoss()

    base_model = load_model(BASE_MODEL_PATH)
    robust_model = load_model(ROBUST_MODEL_PATH)

    epsilons = [0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3]
    base_accs, robust_accs = [], []

    for eps in epsilons:
        base_acc = evaluate_under_attack(base_model, test_loader, eps, criterion)
        robust_acc = evaluate_under_attack(robust_model, test_loader, eps, criterion)
        base_accs.append(base_acc)
        robust_accs.append(robust_acc)
        print(f"eps={eps:.2f}  base={base_acc:.2f}%  robust={robust_acc:.2f}%")

    # ---- Plot ----
    plt.figure(figsize=(8, 5))
    plt.plot(epsilons, base_accs, marker="o", label="Base CNN (undefended)")
    plt.plot(epsilons, robust_accs, marker="o", label="Robust CNN (adversarially trained)")
    plt.xlabel("Epsilon (perturbation budget)")
    plt.ylabel("Test Accuracy (%)")
    plt.title("FGSM Robustness: Base vs. Adversarially Trained CNN")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.ylim(0, 100)

    plot_path = os.path.join(REPORTS_DIR, "accuracy_comparison.png")
    plt.savefig(plot_path, dpi=150, bbox_inches="tight")
    print(f"Plot saved to {plot_path}")

    # ---- Markdown table ----
    md_lines = [
        "# Results: FGSM Attack vs. Adversarial Training Defense\n",
        "| Epsilon | Base CNN Accuracy | Robust CNN Accuracy |",
        "|---------|-------------------:|----------------------:|",
    ]
    for eps, b, r in zip(epsilons, base_accs, robust_accs):
        md_lines.append(f"| {eps:.2f}    | {b:.2f}%             | {r:.2f}%                |")
    md_lines.append("\n![Accuracy comparison](accuracy_comparison.png)\n")

    md_path = os.path.join(REPORTS_DIR, "results.md")
    with open(md_path, "w") as f:
        f.write("\n".join(md_lines))
    print(f"Results table saved to {md_path}")


if __name__ == "__main__":
    main()