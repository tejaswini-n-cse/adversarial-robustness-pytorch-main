"""
Adversarial training.
Trains a fresh CNN (same architecture as Phase 2) using a blended loss of
clean + FGSM-adversarial examples, generated on-the-fly each batch using
the model's CURRENT weights. Saves to models/robust_cnn.pt.
"""

import os
import torch
import torch.nn as nn
import torch.optim as optim
from model import get_dataloaders, SimpleCNN, device
from fgsm_attack import fgsm_attack

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "..", "models", "robust_cnn.pt")

# Perturbation strength used DURING training to generate adversarial examples.
# 0.2 was chosen because Phase 3 showed it collapses the undefended model to
# ~33% accuracy — a strong enough attack that the model can't ignore it.
TRAIN_EPSILON = 0.2

# Blend weight: 0.5 = equal weight to clean loss and adversarial loss,
# per the alpha you confirmed in the theory discussion.
ALPHA = 0.5


def train_adversarial(num_epochs=5, lr=0.001, model_path=MODEL_PATH):
    train_loader, test_loader = get_dataloaders()
    model = SimpleCNN().to(device)  # fresh model — same architecture as Phase 2,
                                      # but a different training regime, so the
                                      # two are a fair apples-to-apples comparison.

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0

        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)

            # ---- STEP 1: INNER MAXIMIZATION ----
            # Generate adversarial examples using the model's CURRENT weights.
            # This is identical machinery to fgsm_attack.py: gradient of loss
            # w.r.t. the INPUT (not the weights), using the model as it is
            # right now, mid-training.
            images.requires_grad = True
            outputs = model(images)
            loss_for_grad = criterion(outputs, labels)

            model.zero_grad()
            loss_for_grad.backward()
            data_grad = images.grad.data

            perturbed_images = fgsm_attack(images, TRAIN_EPSILON, data_grad)
            perturbed_images = perturbed_images.detach()  # cut graph history;
                                                             # treat as a fresh input

            # ---- STEP 2: OUTER MINIMIZATION ----
            # Now do the actual training step: blended loss on clean + adversarial.
            optimizer.zero_grad()

            outputs_clean = model(images.detach())
            loss_clean = criterion(outputs_clean, labels)

            outputs_adv = model(perturbed_images)
            loss_adv = criterion(outputs_adv, labels)

            loss_total = ALPHA * loss_clean + (1 - ALPHA) * loss_adv
            loss_total.backward()
            optimizer.step()

            running_loss += loss_total.item()

        avg_loss = running_loss / len(train_loader)
        print(f"Epoch [{epoch+1}/{num_epochs}] - Avg Blended Loss: {avg_loss:.4f}")

    # Evaluate on CLEAN test set — confirms adversarial training didn't
    # destroy ordinary accuracy.
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = 100 * correct / total
    print(f"Test Accuracy (clean): {accuracy:.2f}%")

    torch.save(model.state_dict(), model_path)
    print(f"Robust model saved to {model_path}")


if __name__ == "__main__":
    train_adversarial()