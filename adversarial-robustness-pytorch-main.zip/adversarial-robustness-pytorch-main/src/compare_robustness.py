"""
validation: runs the same FGSM epsilon sweep against both
the base (undefended) CNN and the adversarially-trained (robust) CNN,
side-by-side, to confirm adversarial training actually flattens the
accuracy-vs-epsilon curve.
"""

import os
import torch
import torch.nn as nn
from model import get_dataloaders, SimpleCNN, device
from fgsm_attack import evaluate_under_attack

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_MODEL_PATH = os.path.join(BASE_DIR, "..", "models", "base_cnn.pt")
ROBUST_MODEL_PATH = os.path.join(BASE_DIR, "..", "models", "robust_cnn.pt")


def load_model(path):
    model = SimpleCNN().to(device)
    model.load_state_dict(torch.load(path, map_location=device))
    model.eval()
    return model


def main():
    _, test_loader = get_dataloaders()
    criterion = nn.CrossEntropyLoss()

    base_model = load_model(BASE_MODEL_PATH)
    robust_model = load_model(ROBUST_MODEL_PATH)

    epsilons = [0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3]

    print(f"{'Epsilon':>8} | {'Base Acc':>10} | {'Robust Acc':>11}")
    print("-" * 35)
    for eps in epsilons:
        base_acc = evaluate_under_attack(base_model, test_loader, eps, criterion)
        robust_acc = evaluate_under_attack(robust_model, test_loader, eps, criterion)
        print(f"{eps:>8.2f} | {base_acc:>9.2f}% | {robust_acc:>10.2f}%")


if __name__ == "__main__":
    main()