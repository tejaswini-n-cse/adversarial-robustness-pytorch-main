"""
Data loading and base CNN architecture definition.
No training loop yet — that's Phase 2.
"""

import torch
import torch.nn as nn
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

# ---- Device configuration ----
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def get_dataloaders(data_dir="./data", batch_size=64):
    """
    Downloads (if needed) and loads MNIST train/test sets.
    Returns train_loader, test_loader.
    """
    transform = transforms.Compose([
        transforms.ToTensor(),  # scales pixels to [0, 1]
    ])

    train_dataset = datasets.MNIST(
        root=data_dir, train=True, download=True, transform=transform
    )
    test_dataset = datasets.MNIST(
        root=data_dir, train=False, download=True, transform=transform
    )

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    return train_loader, test_loader


class SimpleCNN(nn.Module):
    """
    Lightweight CNN for MNIST classification.
    Two conv blocks (conv -> relu -> maxpool) followed by a fully connected head.
    Deliberately small: keeps gradient computation cheap for later
    FGSM and adversarial-training phases.
    """

    def __init__(self, num_classes=10):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=16, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.relu = nn.ReLU()

        # After two 2x2 max-pools on a 28x28 image: 28 -> 14 -> 7
        self.fc1 = nn.Linear(32 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))   # -> [B, 16, 14, 14]
        x = self.pool(self.relu(self.conv2(x)))   # -> [B, 32, 7, 7]
        x = x.view(x.size(0), -1)                 # flatten
        x = self.relu(self.fc1(x))
        x = self.fc2(x)                           # raw logits (no softmax — CrossEntropyLoss applies it)
        return x


if __name__ == "__main__":
    # Sanity check: confirm data loads and model runs a forward pass
    train_loader, test_loader = get_dataloaders()
    model = SimpleCNN().to(device)

    images, labels = next(iter(train_loader))
    images, labels = images.to(device), labels.to(device)

    outputs = model(images)
    print(f"Device: {device}")
    print(f"Batch shape: {images.shape}")   # expect [64, 1, 28, 28]
    print(f"Output shape: {outputs.shape}") # expect [64, 10]
    print("Phase 1 sanity check passed.")