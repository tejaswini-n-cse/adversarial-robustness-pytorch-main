"""
FGSM attack against the trained base CNN.
Evaluates test accuracy as epsilon (perturbation budget) increases.
"""

import os
import torch
import torch.nn as nn
from model import get_dataloaders, SimpleCNN, device

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "..", "models", "base_cnn.pt")


def fgsm_attack(image, epsilon, data_grad):
    """
    image:      original input batch, shape [B, 1, 28, 28], values in [0,1]
    epsilon:    max change allowed per pixel
    data_grad:  gradient of the loss w.r.t. `image`
    """
    sign_data_grad = data_grad.sign()
    perturbed_image = image + epsilon * sign_data_grad
    perturbed_image = torch.clamp(perturbed_image, 0, 1)  # keep valid pixel range
    return perturbed_image


def evaluate_under_attack(model, test_loader, epsilon, criterion):
    correct = 0
    total = 0

    for images, labels in test_loader:
        images, labels = images.to(device), labels.to(device)

        # Gradient needed w.r.t. the INPUT this time, not the weights
        images.requires_grad = True

        outputs = model(images)
        loss = criterion(outputs, labels)

        model.zero_grad()
        loss.backward()

        data_grad = images.grad.data
        perturbed_images = fgsm_attack(images, epsilon, data_grad)

        with torch.no_grad():
            outputs_adv = model(perturbed_images)
            _, predicted = torch.max(outputs_adv, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    return 100 * correct / total


def main():
    _, test_loader = get_dataloaders()

    model = SimpleCNN().to(device)
    model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
    model.eval()

    criterion = nn.CrossEntropyLoss()
    epsilons = [0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3]

    print(f"{'Epsilon':>8} | {'Accuracy':>10}")
    print("-" * 21)
    for eps in epsilons:
        acc = evaluate_under_attack(model, test_loader, eps, criterion)
        print(f"{eps:>8.2f} | {acc:>9.2f}%")


if __name__ == "__main__":
    main()