# Results: FGSM Attack vs. Adversarial Training Defense

| Epsilon | Base CNN Accuracy | Robust CNN Accuracy |
|---------|-------------------:|----------------------:|
| 0.00    | 98.79%             | 98.03%                |
| 0.05    | 94.75%             | 97.57%                |
| 0.10    | 82.23%             | 97.31%                |
| 0.15    | 59.07%             | 98.29%                |
| 0.20    | 33.12%             | 98.48%                |
| 0.25    | 15.10%             | 97.44%                |
| 0.30    | 7.59%             | 94.51%                |

![Accuracy comparison](accuracy_comparison.png)
