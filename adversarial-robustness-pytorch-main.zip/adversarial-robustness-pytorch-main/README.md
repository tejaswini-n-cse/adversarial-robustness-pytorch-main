# Adversarial Attack and Defense Mechanisms in Deep Learning

A PyTorch implementation exploring the vulnerability of CNNs to gradient-based
adversarial attacks (FGSM), and a defense mechanism (adversarial training) that
recovers robustness against them. Built on MNIST with a lightweight CNN to keep
the focus on attack/defense mechanics rather than architecture complexity.

## Overview

Deep neural networks can achieve near-perfect accuracy on clean data while being
highly vulnerable to small, human-imperceptible input perturbations. This project
demonstrates that vulnerability concretely, then implements and evaluates a
standard defense.

**Pipeline:**
1. Train a baseline CNN on clean MNIST.
2. Attack it using the Fast Gradient Sign Method (FGSM) across a range of
   perturbation strengths (epsilon).
3. Retrain a second CNN using adversarial training — a blended clean/adversarial
   loss — to defend against this exact attack.
4. Compare both models' accuracy under attack, side by side.

## Project Structure
adversarial-ml-fgsm/
├── data/                    # MNIST (auto-downloaded, gitignored)
├── models/                  # Saved checkpoints (gitignored)
│   ├── base_cnn.pt          # Undefended baseline
│   └── robust_cnn.pt        # Adversarially trained
├── notebooks/                # Exploratory notebooks
├── reports/                  # Writeups, plots
├── src/
│   ├── model.py               # Data loading + SimpleCNN architecture
│   ├── train.py                # Baseline training loop
│   ├── fgsm_attack.py          # FGSM attack + epsilon-sweep evaluation
│   ├── adversarial_train.py    # Adversarial training (blended loss)
│   └── compare_robustness.py   # Side-by-side base vs. robust comparison
├── requirements.txt
└── README.md

## Setup

```cmd
python -m venv venv
venv\Scripts\activate.bat
pip install --no-cache-dir -r requirements.txt
```

Dependencies are pinned to a CPU-only PyTorch build — no GPU required.

## Usage

Run in order:

```cmd
python src\train.py                 # trains base_cnn.pt (~98.79% clean accuracy)
python src\fgsm_attack.py           # attacks base_cnn.pt across epsilon sweep
python src\adversarial_train.py     # trains robust_cnn.pt via adversarial training
python src\compare_robustness.py    # side-by-side comparison, both models
```

## Method

**FGSM** perturbs an input in the direction that maximizes loss, subject to a
per-pixel budget of epsilon:
x_adv = x + epsilon * sign(∇x L(θ, x, y))

Unlike training (which moves weights to *minimize* loss), FGSM moves the
*input* to *maximize* loss, holding weights fixed.

**Adversarial training** generates FGSM examples on the fly during training
using the model's current weights, then trains on a blended loss:
L_total = α * L(θ, x, y) + (1-α) * L(θ, x_adv, y)

with α = 0.5 and training epsilon = 0.2.

## Results

| Epsilon | Base CNN Accuracy | Robust CNN Accuracy |
|---------|-------------------:|----------------------:|
| 0.00    | 98.79%             | 98.03%                |
| 0.05    | 94.75%             | 97.57%                |
| 0.10    | 82.23%             | 97.31%                |
| 0.15    | 59.07%             | 98.29%                |
| 0.20    | 33.12%             | 98.48%                |
| 0.25    | 15.10%             | 97.44%                |
| 0.30    | 7.59%              | 94.51%                |

The undefended model collapses from 98.79% to 7.59% as epsilon increases.
The adversarially trained model stays within 94–98% across the entire sweep —
losing under 1 point of clean accuracy as the cost of this robustness.

**Note:** robustness peaks near epsilon = 0.15–0.20, matching the epsilon used
during adversarial training (0.2). This reflects a known property of FGSM
adversarial training: robustness concentrates around the specific perturbation
strength seen during training, rather than generalizing uniformly to all
attack strengths.

## Tech Stack

Python, PyTorch (CPU), torchvision, matplotlib, numpy

## Future Work

- Projected Gradient Descent (PGD) as a stronger, iterative attack
- Extend to a deeper architecture / more complex dataset (CIFAR-10)